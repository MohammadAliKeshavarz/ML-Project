# ML_Graduate_Project_TA
This repository contains the code related to the image project for the advanced machine course taught by Dr. Seyedin.

## Dependencies

To run the code, please install all its dependencies:
```sh
pip install -r requirements.txt
```

## Usage
```python
!python test.py

```
